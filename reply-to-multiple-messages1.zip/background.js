
//var onload=function(){browser.rtmm_bgrndAPI.LoadsetEverythingUp()}
function onload(){
    browser.rtmm_bgrndAPI.LoadsetEverythingUp();
}


onload();


//browser.runtime.onInstalled.addListener(onload);
